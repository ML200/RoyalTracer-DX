// ═══════════════════════════════════════════════════════════════════
// Includes_v8.hlsli — Unified include for all passes.
//
// Compute shaders:  #define COMPUTE_PASS before including.
// Raygen/hit/miss:  Include directly (no define needed).
// ═══════════════════════════════════════════════════════════════════

#ifndef INCLUDES_V8_HLSLI
#define INCLUDES_V8_HLSLI

// ─── Push constants ────────────────────────────────────────────────
cbuffer Push : register(b1)
{
    uint2 gImageSize;          // [0-1]
    uint  g_InputStackIdx;     // [2]
    uint  g_OutputStackIdx;    // [3]
    uint  rs_tempMcapDI;       // [4]
    uint  rs_tempMcapGI;       // [5]
    uint  rs_spatCountMaxDI;   // [6]
    uint  rs_spatCountMinDI;   // [7]
    uint  rs_spatRadMaxDI;     // [8]
    uint  rs_spatRadMinDI;     // [9]
    uint  rs_spatCountMaxGI;   // [10]
    uint  rs_spatCountMinGI;   // [11]
    uint  rs_spatRadMaxGI;     // [12]
    uint  rs_spatRadMinGI;     // [13]
    uint  rs_flags;            // [14] bit0=tempDI, bit1=tempGI, bit2=spatDI, bit3=spatGI
    float rs_reuseRoughnessMin;// [15]
    float rs_reuseRoughnessMax;// [16]
    uint  rs_spatTriesGI;      // [17] total attempts to find GI spatial neighbors
    uint  rs_spatTriesDI;      // [18] total attempts to find DI spatial neighbor
    uint  _pad19;              // [19]
};

// ─── Image size convenience macros ─────────────────────────────────
#define IMG_W (gImageSize.x)
#define IMG_H (gImageSize.y)

#ifdef COMPUTE_PASS
    // Compute shaders emulate DispatchRaysIndex/Dimensions for shared code
    #define gImageWidth  (gImageSize.x)
    #define gImageHeight (gImageSize.y)
    #define DispatchRaysDimensions() uint3(gImageWidth, gImageHeight, 1)
    static uint3 gDispatchIdx;
    #define DispatchRaysIndex()      gDispatchIdx
#endif

// ─── Inline ray tracing support ────────────────────────────────────
#define ENABLE_RAY_QUERY_INLINE

// ─── Samplers & LUTs ───────────────────────────────────────────────
SamplerState   g_sampler     : register(s0);
SamplerState   g_sampler_LUT : register(s1);
Texture2DArray g_LUT         : register(t33);

// ─── Wavefront compaction ──────────────────────────────────────────
RWByteAddressBuffer          g_GlobalCounters : register(u34);
RWStructuredBuffer<uint3>    g_IndirectArgs   : register(u35);
RWStructuredBuffer<uint2>    g_Stack0         : register(u36);
RWStructuredBuffer<uint2>    g_Stack1         : register(u37);
RWByteAddressBuffer          g_SortCount      : register(u60);
RWByteAddressBuffer          g_SortOffset     : register(u61);
RWByteAddressBuffer          g_SortBounds     : register(u62);

// ─── Camera ────────────────────────────────────────────────────────
cbuffer CameraParams : register(b0)
{
    float4x4 view;
    float4x4 projection;
    float4x4 viewI;
    float4x4 projectionI;
    float4x4 prevView;
    float4x4 prevProjection;
    float  time;
    float2 jitter;
    float  _cbpad0;
    // Sun settings (runtime-editable)
    float sunLatitude;
    float sunLongitude;
    float sunDayOfYear;
    float sunSimSpeed;
    float sunStartUTCHours;
    float sunNightSpeedup;
    float sunTurbidity;
    float sunSunIntensity;
    float sunSkyIntensity;
    float _sunpad0, _sunpad1, _sunpad2;
}

#define SUN_LATITUDE_DEG    sunLatitude
#define SUN_LONGITUDE_DEG   sunLongitude
#define SUN_DAY_OF_YEAR     sunDayOfYear
#define SUN_SIM_SPEED       sunSimSpeed
#define SUN_START_UTC_HOURS sunStartUTCHours
#define SUN_NIGHT_SPEEDUP   sunNightSpeedup
#define SUN_TURBIDITY       sunTurbidity
#define SUN_INTENSITY_VAL   sunSunIntensity
#define SKY_INTENSITY_VAL   sunSkyIntensity
#define SKY_INTENSITY       sunSkyIntensity

// ─── Core utility headers ──────────────────────────────────────────
#include "Constants_v8.hlsli"
#include "Common_v8.hlsli"
#include "Data_v8.hlsli"
#include "Random_v8.hlsli"
#include "Compression_v8.hlsli"
#include "HitState_v8.hlsli"

// ─── Output / scratch / reservoir buffers ──────────────────────────
RWTexture2DArray<float4> gOutput             : register(u0);
RWTexture2D<float4>      gPermanentData      : register(u1);
RWTexture2DArray<float4> gScratchPing        : register(u8);

RWByteAddressBuffer g_sample_current         : register(u6);
RWByteAddressBuffer g_sample_last            : register(u7);
RWByteAddressBuffer g_Reservoirs_current_di  : register(u2);
RWByteAddressBuffer g_Reservoirs_last_di     : register(u3);
RWByteAddressBuffer g_Reservoirs_current_gi  : register(u4);
RWByteAddressBuffer g_Reservoirs_last_gi     : register(u5);
RWByteAddressBuffer g_InitialBSDFRays        : register(u9);
RWByteAddressBuffer g_pathStateBuffer        : register(u10);

// ─── Scene data ────────────────────────────────────────────────────
StructuredBuffer<STriVertex>         BTriVertex          : register(t2);
StructuredBuffer<int>                indices             : register(t1);
RaytracingAccelerationStructure      SceneBVH            : register(t0);
StructuredBuffer<InstanceProperties> instanceProps       : register(t3);
StructuredBuffer<uint>               materialIDs         : register(t4);
StructuredBuffer<Material>           materials           : register(t5);
StructuredBuffer<LightTriangle>      g_EmissiveTriangles : register(t6);
StructuredBuffer<uint>               gTriToLightId       : register(t15);

// Light tree
StructuredBuffer<LightTLASNodeGpu> gLT_TLAS         : register(t9);
StructuredBuffer<LightBLASNodeGpu> gLT_BLAS         : register(t10);
StructuredBuffer<BlasRangeGpu>     gLT_Range        : register(t11);
Buffer<uint>                       gLT_LeafTriIndex : register(t12);
Buffer<float>                      gLT_LeafAliasProb: register(t16);
Buffer<uint>                       gLT_LeafAliasIdx : register(t17);

// ─── Shading & material headers ────────────────────────────────────
#include "LightTree_v8.hlsli"
#include "Sample_Data_v8.hlsli"
#include "Path_State_v8.hlsli"
#include "Fresnel_v8.hlsli"
#include "Material_Common_v8.hlsli"
#include "Material_GGX_v8.hlsli"
#include "Material_Lambertian_v8.hlsli"
#include "Material_Coat_v8.hlsli"
#include "Material_Sheen_v8.hlsli"
#include "BXDF_v8.hlsli"

// ─── Sampling, reservoirs, ray tracing ─────────────────────────────
#include "Path_Sampler_v8.hlsli"
#include "SunSampler_v8.hlsli"
#include "Clouds_v8.hlsli"
#include "Reservoir_DI_v8.hlsli"
#include "Reservoir_GI_v8.hlsli"
#include "PayloadPath_v8.hlsli"
#include "Inline_RT_v8.hlsli"

// Temporal candidate tests (depend on GetMatIDFast from Inline_RT and ReconstructPosition from SurfaceVertex)
inline bool TestTemporalCandidate_DI(
    int2   coord,
    float2 dims,
    RWByteAddressBuffer sampleBuf,
    uint   myMatID,
    float3 myN1g,
    float3 myPos,
    out uint   outPixelIdx,
    out uint   outInstID,
    out uint   outPrimID,
    out float2 outBary)
{
    outPixelIdx = 0xFFFFFFFFu;
    outInstID   = 0;
    outPrimID   = 0;
    outBary     = float2(0, 0);

    if (coord.x < 0 || coord.y < 0 || coord.x >= (int)dims.x || coord.y >= (int)dims.y)
        return false;

    uint tpx = MapPixelID(dims, (uint2)coord);

    if (load_isEmitter(sampleBuf, tpx))
        return false;

    uint rI = load_instID(sampleBuf, tpx);
    uint rP = load_primID(sampleBuf, tpx);
    /*if (GetMatIDFast(rI, rP) != myMatID)
        return false;*/

    float3 ng = load_n1_g_with_instID(sampleBuf, tpx, rI);
    if (RejectNormal_DI(myN1g, ng, 0.36f))
        return false;

    float2 rB = load_bary(sampleBuf, tpx);
    float3 xr = ReconstructPosition(rI, rP, rB);
    if (RejectDistance_DI(myPos, xr, myN1g, 0.4f))
        return false;

    outPixelIdx = tpx;
    outInstID   = rI;
    outPrimID   = rP;
    outBary     = rB;
    return true;
}

inline bool TestTemporalCandidate_GI(
    int2   coord,
    float2 dims,
    RWByteAddressBuffer sampleBuf,
    uint   myMatID,
    float3 myN1s,
    float3 myPos,
    out uint   outPixelIdx,
    out uint   outInstID,
    out uint   outPrimID,
    out float2 outBary)
{
    outPixelIdx = 0xFFFFFFFFu;
    outInstID   = 0;
    outPrimID   = 0;
    outBary     = float2(0, 0);

    if (coord.x < 0 || coord.y < 0 || coord.x >= (int)dims.x || coord.y >= (int)dims.y)
        return false;

    uint tpx = MapPixelID(dims, (uint2)coord);

    if (load_isEmitter(sampleBuf, tpx))
        return false;

    uint rI = load_instID(sampleBuf, tpx);
    uint rP = load_primID(sampleBuf, tpx);
    /*if (GetMatIDFast(rI, rP) != myMatID)
        return false;*/

    float3 ns = load_n1_s_with_instID(sampleBuf, tpx, rI);
    if (RejectNormal_GI(myN1s, ns, 0.36f))
        return false;

    float2 rB = load_bary(sampleBuf, tpx);
    float3 xr = ReconstructPosition(rI, rP, rB);
    if (RejectDistance_GI(myPos, xr, myN1s, 0.4f))
        return false;

    outPixelIdx = tpx;
    outInstID   = rI;
    outPrimID   = rP;
    outBary     = rB;
    return true;
}

#include "Camera_ray_v8.hlsli"
#include "VolumeStackPacked_v8.hlsli"
#include "MIS_v8.hlsli"

// ─── DLSS-RR resources (only needed by shading pass) ──────────────
#ifdef COMPUTE_PASS
RWTexture2D<float>  g_dlssDepth          : register(u11);
RWTexture2D<float2> g_dlssMVec           : register(u12);
RWTexture2D<float4> g_dlssNormals        : register(u13);
RWTexture2D<float4> g_dlssDiffuseAlbedo  : register(u14);
RWTexture2D<float4> g_dlssOutput         : register(u15);
RWTexture2D<float4> g_dlssSpecularAlbedo : register(u16);
RWTexture2D<float>  g_dlssRoughness      : register(u17);
RWTexture2D<float2> g_dlssSpecMVec       : register(u18);
RWTexture2D<float>  g_dlssSpecHitDist    : register(u19);
RWTexture2D<float4> g_dlssTransparency   : register(u20);
RWTexture2D<float4> g_dlssColorPreTrans  : register(u21);
RWTexture2D<float4> g_dlssInput          : register(u22);
RWTexture2D<float>  g_dlssBiasHint       : register(u23);
#endif

#endif // INCLUDES_V8_HLSLI
